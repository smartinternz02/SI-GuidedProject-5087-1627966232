import numpy as np
from flask import Flask, request, jsonify, render_template
from joblib import load

from tensorflow.keras.models import load_model
app = Flask(__name__)

model = load_model("clinicalheartfailure.h5")
sc = load("transform1.save")

@app.route('/')
def home():
    return render_template('index2.html')


@app.route('/y_predict', methods=['POST'])
def y_predict():
    
    a = request.form['age']
    b = request.form['anaemia']
    c = request.form['creatinine']
    d = request.form['diabetes']
    e = request.form['ejection_fraction']
    f = request.form['high_blood_pressure']
    g = request.form['platelets']
    h = request.form['serum_creatinine']
    i = request.form['serum_sodium']
    j = request.form['gender']
    k = request.form['smoking']
    l = request.form['time']
    
    
    total = [[a,b,c,d,e,f,g,h,i,j,k,l]]
    np.reshape(total, (12,))
    prediction = model.predict(sc.transform(total))

    if(prediction == 0):
        output = "He|She might survive"
    else:
        output = "He|She might die from heart attack. "

    return render_template('index2.html', prediction_text='Result: {}'.format(output))


if __name__ == "__main__":
    app.run(port=8086, debug=True)
